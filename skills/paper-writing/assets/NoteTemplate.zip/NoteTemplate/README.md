# NoteTemplate

A reusable LaTeX note/book template extracted from the visual style of the current Note project.

## Folders

- `Chinese/`: Chinese version (`ctexbook`, XeLaTeX)
- `English/`: English version (`book`, XeLaTeX)

Each version contains:

- `main.tex` — main entry
- `style.tex` — layout, colors, theorem environments, boxes, notation, bibliography configuration
- `references.bib` — bibliography entry point for `biblatex`/`biber`
- `chapters/` — chapter files
- `figures/` — figures

## Compile

Run inside either `Chinese/` or `English/`:

```bash
xelatex main.tex
biber main
xelatex main.tex
xelatex main.tex
```

The bibliography is already connected through:

```tex
\addbibresource{references.bib}
```

and printed in `main.tex` using `\printbibliography`.
